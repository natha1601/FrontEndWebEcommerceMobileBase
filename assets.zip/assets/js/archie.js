$(document).ready(function() {
    //clear field
    $(".clear-field").click(function() {
        $(this).parent('.p__field-container').find("input").val('');
        $(this).parent('.p__field-container').find("input").focus();
        $(this).parent('.form-group-pin').find("input").val('');
        $(this).parent('.form-group-pin').find("input").focus();
        $(this).removeClass("visible");
        $(this).addClass("hidden");
        $(this).parent('.p__field-container').addClass('empty');
        $(this).parent('.form-group-pin').addClass('empty');
        $('.denom .denom--prabayar-pln').addClass('hidden');
        $('a.btn-next-payment').removeClass('active');
        $("button.btn-menu-utama").prop("disabled", true);
        $("p.warning").addClass("hidden");
        $(".visible-denom").addClass("hidden");
        $(".label-ops").addClass("hidden");
    });

    $('.p__field-container input:empty').closest('div').addClass('clear');

    $('.p__field-container input.p__field').keyup(function() {
        if ($(this).val().trim() !== '') {
            $(this).closest('div').removeClass('clear');
            $(".clear-field").removeClass("hidden");
            $(".ch-portlet__body.ch-denom").removeClass("hidden");
            $(".label-ops").removeClass("hidden");
        } else {
            $(this).closest('div').addClass('clear');
        }
    });

    $('.form-group-pin input:empty').closest('div').addClass('clear');

    $('.form-group-pin input.p__field').keyup(function() {
        if ($(this).val().trim() == '123456') {
            $(this).closest('div').removeClass('clear');
            $(".clear-field").removeClass("hidden");
            $(".visible-denom").removeClass("hidden");
            $(".label-ops").removeClass("hidden");
            $("button.btn-menu-utama").prop("disabled", false);
        } else {
            $(this).closest('div').addClass('clear');
        }
    });

    $('.p__field-container.p__field-bg #input_pelanggan').keyup(function() {
        if ($(this).val().trim() == '2018080111') {
            $('a.btn-brand.btn-brand__PDAM').addClass('active');
        } else {
            $('a..btn-brand.btn-brand__PDAM').removeClass('active');
        }
    });

    $('.p__field-container.p__field-bg #input_numb_bpjs').keyup(function() {
        if ($(this).val().trim() == '0002018080201') {
            $('a.btn-brand.btn-brand__BPJS').addClass('active');
        } else {
            $('a.btn-brand.btn-brand__BPJS').removeClass('active');
        }
    });

    $('.p__field-container.p__field-bg #input_numb_telkom').keyup(function() {
        if ($(this).val().trim() == '0002018080211') {
            $('a.btn-brand.btn-brand__Telkom').addClass('active');
        } else {
            $('a.btn-brand.btn-brand__Telkom').removeClass('active');
        }
    });

    $('.p__field-container.p__field-bg #input_numb_phone').keyup(function () {
        if ($(this).val().trim() !== '') {
            $('a.btn-brand.btn-brand__PLN_Pasca').addClass('active');
        } else {
            $('a.btn-brand.btn-brand__PLN_Pasca').removeClass('active');
        }
    });

    $(".btn-brand").click(function () {
        $('.ch-portlet__body.ch-paydenom').removeClass('hidden');
        $('a.btn-brand.btn-brand__Telkom').addClass('hidden');
        $('a.btn-brand.btn-brand__PDAM').addClass('hidden');
        $('a.btn-brand.btn-brand__PLN_Pasca').addClass('hidden');
    });

    $(".p__field-container.p__field-bg #input_phone_number").click(function() {
        if ($('.p__field-container input.p__field#input_numb_pln_prabayar').val().trim() == '20180801001') {
            $('.ch-portlet__body.ch-prabayar').removeClass('hidden');
        } else {
            $('.ch-portlet__body.ch-prabayar').addClass('hidden');
        }
    });



    $("#Btn_Minus").click(function(){
        if ($(this).next().val() > 1) {
            if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
        }
    });

    $("#Btn_Plus").click(function(){

        if ($(this).prev().val() < 10) {
            $(this).prev().val(+$(this).prev().val() + 1);
        }
    });

    $("#Btn_Tukar_Poin").click(function(){
        $(".ch-footer__pass").removeClass("hidden");
    });

    $("#Field_Slide_Title_Opened").click(function() {
        $("#Field_Slide").slideToggle("slow");
    });

    $("#Field_Slide_Title_Closed").click(function() {
        $("#Field_Slide").slideToggle("slow");
    });

    $("#input_pin_valid").keyup(function(){
        if($(this).val().trim() !== ""){
            $(".clear-field").removeClass("hidden");
            $("#btn_confirm").removeAttr("disabled");
        } else{
            $(".clear-field").addClass("hidden");
            $("#btn_confirm").attr("disabled", "disabled");
        }
    });

    $(".clear-field").click(function(){
        $("#input_pin_valid").val("");
        $("#btn_confirm").attr("disabled", "disabled");
    });

    $("#input_numb_bpjs").keyup(function(){
        if($(this).val().trim() !== ""){
            $(".ch-btn__lanjutkan").removeAttr("disabled");
        } else {
            $(".ch-btn__lanjutkan").attr("disabled", "disabled");
        }
    });

    $("#input_pin_valid").keyup(function(){
        if($(this).val().trim() !== ""){
            $("#btn_confirm").removeAttr("disabled");
        } else {
            $("#btn_confirm").attr("disabled", "disabled");
        }
    });

    $(".ch-btn__lanjutkan").click(function(){
        if($("#input_location").val().trim() == "" && $("#input_pelanggan").val().trim() == ""){
            $("#wilayah_pelanggan").removeClass("hidden");
            $("#wilayah_perusahaan").addClass("hidden");
            $("#id_pelanggan").addClass("hidden");
        } else if($("#input_location").val().trim() == ""){
            $("#wilayah_perusahaan").removeClass("hidden");
            $("#wilayah_pelanggan").addClass("hidden");
            $("#id_pelanggan").addClass("hidden");
        } else if ($("#input_pelanggan").val().trim() == ""){
            $("#id_pelanggan").removeClass("hidden");
            $("#wilayah_pelanggan").addClass("hidden");
            $("#wilayah_perusahaan").addClass("hidden");
        } else{
            document.location.href = "konfirmasi-pembayaran-pdam.html";
        }
    });

    $("#Input_Nomor_Pelanggan").keyup(function(){
        if($(this).val().trim() !== ""){
            $("#Button_Lanjutkan_KP_Adira").removeAttr("disabled");
        } else {
            $("#Button_Lanjutkan_KP_Adira").attr("disabled", "disabled");
        }
    });

    $(".input-pass-cicilan").keyup(function(){
        if($(this).val().trim() !== ""){
            $(".button-confirm-cicilan").removeAttr("disabled");
        } else {
            $(".button-confirm-cicilan").attr("disabled", "disabled");
        }
    });

    $("#input_pin_valid").keyup(function(){
        if($(this).val().trim() !== ""){
            $(".ch-btn__confirm").removeAttr("disabled");
        } else {
            $(".ch-btn__confirm").attr("disabled", "disabled");
        }
    });
});

/**
 *  Jquery Slider Homepage 
 */

var $slider = $(".slider"),
    $bullets = $(".bullets");

function calculateHeight() {
    var height = $(".slide.active").outerHeight();
    $slider.height(height);
}

$(window).resize(function() {
    calculateHeight();
    clearTimeout($.data(this, 'resizeTimer'));
});

function resetSlides() {
    $(".slide.inactive").removeClass("inactiveRight").removeClass("inactiveLeft");
}

function gotoSlide($activeSlide, $slide, className) {
    $activeSlide.removeClass("active").addClass("inactive " + className);
    $slide.removeClass("inactive").addClass("active");
    calculateHeight();
    resetBullets();
    setTimeout(resetSlides, 300);
}

$(".next").on("click", function() {
    var $activeSlide = $(".slide.active"),
        $nextSlide = $activeSlide.next(".slide").length != 0 ? $activeSlide.next(".slide") : $(".slide:first-child");
    console.log($nextSlide);
    gotoSlide($activeSlide, $nextSlide, "inactiveLeft");
});
$(".previous").on("click", function() {
    var $activeSlide = $(".slide.active"),
        $prevSlide = $activeSlide.prev(".slide").length != 0 ? $activeSlide.prev(".slide") : $(".slide:last-child");

    gotoSlide($activeSlide, $prevSlide, "inactiveRight");
});
$(document).on("click", ".bullet", function() {
    if ($(this).hasClass("active")) {
        return;
    }
    var $activeSlide = $(".slide.active");
    var currentIndex = $activeSlide.index();
    var targetIndex = $(this).index();
    console.log(currentIndex, targetIndex);
    var $theSlide = $(".slide:nth-child(" + (targetIndex + 1) + ")");
    gotoSlide($activeSlide, $theSlide, currentIndex > targetIndex ? "inactiveRight" : "inactiveLeft");
});

function addBullets() {
    var total = $(".slide").length,
        index = $(".slide.active").index();
    for (var i = 0; i < total; i++) {
        var $bullet = $("<div>").addClass("bullet");
        if (i == index) {
            $bullet.addClass("active");
        }
        $bullets.append($bullet);
    }
}

function resetBullets() {
    $(".bullet.active").removeClass("active");
    var index = $(".slide.active").index() + 1;
    console.log(index);
    $(".bullet:nth-child(" + index + ")").addClass("active");
}
addBullets();
calculateHeight();

/**
 * end Slider Homepage
 */


/**
 * Menu Nav Side
 */

function openNav() {
    document.getElementById("ch-menu_SideNav").style.width = "250px";
}

function closeNav() {
    document.getElementById("ch-menu_SideNav").style.width = "0";
}

/**
 * end Menu Nav Side
 */


/*http://laravel.io/forum/02-08-2014-ajax-autocomplete-input*/
var countries = {
    "BKO": "PDAM Bangko",
    "JMB": "PDAM Jambi",
    "KLT": "PDAM Kuala Tungkal",
    "MBN": "PDAM Muara Bulian",
    "MRB": "PDAM Muara Bungo",
    "MSK": "PDAM Muara Sabak",
    "MRT": "PDAM Muara Tebo",
    "SRL": "PDAM Sarolangun",
    "SNT": "PDAM Sengeti",
    "SPN": "PDAM Sungai Penuh",
    "CKG": "PDAM Cakung",
    "GGP": "PDAM Grogol Petamburan",
    "KSU": "PDAM Kepulauan Seribu Utara",
    "KYB": "PDAM Kebayoran Baru",
    "TJP": "PDAM Tanjungpriok",
    "TNA": "PDAM Tanak Abang",
    "BTU": "PDAM Batu",
    "BYW": "PDAM Banyuwangi",
    "BLT": "PDAM Blitar",
    "MLG": "PDAM Malang",
    "PBL": "PDAM Probolinggo",
    "SBY": "PDAM Surabaya"
};

var countriesString = [
    "Andorra",
    "Andorra Test",
    "United Arab Emirates"
];

var countriesArray = $.map(countries, function(value, key) {
    return {
        value: value,
        data: key
    };
});

// Initialize ajax autocomplete:
$('#input_location').autocomplete({
    // serviceUrl: '/autosuggest/service/url',
    //lookup: countriesString,
    lookup: countriesArray,
    lookupFilter: function(suggestion, originalQuery, queryLowerCase) {
        var re = new RegExp('\\b' + $.Autocomplete.utils.escapeRegExChars(queryLowerCase), 'gi');
        return re.test(suggestion.value);
    },
    onSelect: function(suggestion) {
        $('#selction-ajax').html('You selected: ' + suggestion.value + ', ' + suggestion.data);
    },
    onHint: function(hint) {
        $('#autocomplete-ajax-x').val(hint);
    },
    onInvalidateSelection: function() {
        $('#selction-ajax').html('You selected: none');
    }
});